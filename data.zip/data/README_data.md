# Data

## Introduction
This is the data set with diffrent catalyst's as cathodes.
Platinum was used as the anode electrode for all tests.

## Data
The raw data begins at line 62. Before that is general information about
the test.
